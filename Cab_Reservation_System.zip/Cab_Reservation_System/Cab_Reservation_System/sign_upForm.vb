﻿Imports System.Data
Imports System.Data.OleDb

Public Class sign_upForm

    Dim counter As Integer
    Dim conn As OleDb.OleDbConnection = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\cabDatabase.accdb;Persist Security Info=True")
    Dim cmd As OleDb.OleDbCommand
    Dim usern, epass, cpass As String
    Dim sql As String
    Dim dr As IDataReader

    Private Sub signUpButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles signUpButton.Click
        Try
            usern = userNTextBox.Text
            epass = enterPTextBox.Text
            cpass = confirmPTextBox.Text

            If (epass = cpass) Then
                conn.Open()

                sql = "select * from user_table where user_name ='" & usern & "' and user_pass='" & epass & "'"
                cmd = New OleDbCommand(sql, conn)

                dr = cmd.ExecuteReader()


                If (dr.Read = True) Then
                    MessageBox.Show("Already registered.")
                    GoTo already
                End If


                sql = "INSERT INTO user_table(  user_name, user_pass, acc_balance , total_reservations)VALUES('" & usern & "','" & epass & "','150000','0');"
                cmd = New OleDbCommand(sql, conn)
                Dim icount As Integer = cmd.ExecuteNonQuery
                MessageBox.Show(" Registered Successfully..", "Success", MessageBoxButtons.OK)
                conn.Close()
                loginForm.username = usern
                loginForm.password = epass
                reserveForm.Show()
                Me.Hide()
            Else
                MessageBox.Show("Unmatched Password.")
already:
                userNTextBox.Clear()
                enterPTextBox.Clear()
                confirmPTextBox.Clear()
                userNTextBox.Focus()
                conn.Close()


            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

  
    Private Sub sign_upForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class