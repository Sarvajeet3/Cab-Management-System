﻿Imports System.Data
Imports System.Data.OleDb

Public Class historyForm

    Dim counter As Integer
    Dim conn As OleDb.OleDbConnection = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\cabDatabase.accdb;Persist Security Info=True")
    Dim cmd As OleDb.OleDbCommand
    Dim sql As String
    Dim dr As IDataReader

    Private Sub historyForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim ad As OleDbDataAdapter = New OleDbDataAdapter("select cab_id, pickup_point, Reserved_date , payment from history_table where cust_id =" & reserveForm.user_id & " order by Reserved_date", conn)
        Dim ds As DataSet = New DataSet()
        ad.Fill(ds)
        DataGridView1.DataSource = ds.Tables(0)

    End Sub

    Private Sub ToolStripButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton1.Click
        Me.Hide()
        reserveForm.Focus()
    End Sub
End Class