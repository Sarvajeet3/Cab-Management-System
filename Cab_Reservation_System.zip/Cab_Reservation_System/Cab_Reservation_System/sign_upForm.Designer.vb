﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class sign_upForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(sign_upForm))
        Me.userNLabel = New System.Windows.Forms.Label()
        Me.enterPLabel = New System.Windows.Forms.Label()
        Me.confirmPLabel = New System.Windows.Forms.Label()
        Me.Sign_Label = New System.Windows.Forms.Label()
        Me.userNTextBox = New System.Windows.Forms.TextBox()
        Me.enterPTextBox = New System.Windows.Forms.TextBox()
        Me.confirmPTextBox = New System.Windows.Forms.TextBox()
        Me.signUpButton = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'userNLabel
        '
        Me.userNLabel.AutoSize = True
        Me.userNLabel.BackColor = System.Drawing.Color.RoyalBlue
        Me.userNLabel.Location = New System.Drawing.Point(121, 168)
        Me.userNLabel.Name = "userNLabel"
        Me.userNLabel.Size = New System.Drawing.Size(73, 17)
        Me.userNLabel.TabIndex = 0
        Me.userNLabel.Text = "Username"
        '
        'enterPLabel
        '
        Me.enterPLabel.AutoSize = True
        Me.enterPLabel.BackColor = System.Drawing.Color.RoyalBlue
        Me.enterPLabel.Location = New System.Drawing.Point(121, 293)
        Me.enterPLabel.Name = "enterPLabel"
        Me.enterPLabel.Size = New System.Drawing.Size(107, 17)
        Me.enterPLabel.TabIndex = 1
        Me.enterPLabel.Text = "Enter Password"
        '
        'confirmPLabel
        '
        Me.confirmPLabel.AutoSize = True
        Me.confirmPLabel.BackColor = System.Drawing.Color.CornflowerBlue
        Me.confirmPLabel.Location = New System.Drawing.Point(121, 408)
        Me.confirmPLabel.Name = "confirmPLabel"
        Me.confirmPLabel.Size = New System.Drawing.Size(121, 17)
        Me.confirmPLabel.TabIndex = 2
        Me.confirmPLabel.Text = "Confirm Password"
        '
        'Sign_Label
        '
        Me.Sign_Label.AutoSize = True
        Me.Sign_Label.BackColor = System.Drawing.Color.RoyalBlue
        Me.Sign_Label.Location = New System.Drawing.Point(322, 71)
        Me.Sign_Label.Name = "Sign_Label"
        Me.Sign_Label.Size = New System.Drawing.Size(59, 17)
        Me.Sign_Label.TabIndex = 3
        Me.Sign_Label.Text = "Sign-Up"
        '
        'userNTextBox
        '
        Me.userNTextBox.Location = New System.Drawing.Point(397, 165)
        Me.userNTextBox.Name = "userNTextBox"
        Me.userNTextBox.Size = New System.Drawing.Size(174, 22)
        Me.userNTextBox.TabIndex = 4
        '
        'enterPTextBox
        '
        Me.enterPTextBox.Location = New System.Drawing.Point(397, 290)
        Me.enterPTextBox.Name = "enterPTextBox"
        Me.enterPTextBox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.enterPTextBox.Size = New System.Drawing.Size(174, 22)
        Me.enterPTextBox.TabIndex = 5
        '
        'confirmPTextBox
        '
        Me.confirmPTextBox.Location = New System.Drawing.Point(397, 405)
        Me.confirmPTextBox.Name = "confirmPTextBox"
        Me.confirmPTextBox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.confirmPTextBox.Size = New System.Drawing.Size(174, 22)
        Me.confirmPTextBox.TabIndex = 6
        '
        'signUpButton
        '
        Me.signUpButton.Location = New System.Drawing.Point(314, 502)
        Me.signUpButton.Name = "signUpButton"
        Me.signUpButton.Size = New System.Drawing.Size(81, 35)
        Me.signUpButton.TabIndex = 7
        Me.signUpButton.Text = "Sign-Up"
        Me.signUpButton.UseVisualStyleBackColor = True
        '
        'sign_upForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(770, 641)
        Me.Controls.Add(Me.signUpButton)
        Me.Controls.Add(Me.confirmPTextBox)
        Me.Controls.Add(Me.enterPTextBox)
        Me.Controls.Add(Me.userNTextBox)
        Me.Controls.Add(Me.Sign_Label)
        Me.Controls.Add(Me.confirmPLabel)
        Me.Controls.Add(Me.enterPLabel)
        Me.Controls.Add(Me.userNLabel)
        Me.DoubleBuffered = True
        Me.Name = "sign_upForm"
        Me.Text = "sign_upForm"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents userNLabel As System.Windows.Forms.Label
    Friend WithEvents enterPLabel As System.Windows.Forms.Label
    Friend WithEvents confirmPLabel As System.Windows.Forms.Label
    Friend WithEvents Sign_Label As System.Windows.Forms.Label
    Friend WithEvents userNTextBox As System.Windows.Forms.TextBox
    Friend WithEvents enterPTextBox As System.Windows.Forms.TextBox
    Friend WithEvents confirmPTextBox As System.Windows.Forms.TextBox
    Friend WithEvents signUpButton As System.Windows.Forms.Button
End Class
