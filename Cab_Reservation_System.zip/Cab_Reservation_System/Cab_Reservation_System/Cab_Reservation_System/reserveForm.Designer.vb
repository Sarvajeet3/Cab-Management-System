﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class reserveForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(reserveForm))
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.reserveToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.historyToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.NameLabel = New System.Windows.Forms.Label()
        Me.totalLabel = New System.Windows.Forms.Label()
        Me.accLabel = New System.Windows.Forms.Label()
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ToolStrip1
        '
        Me.ToolStrip1.BackColor = System.Drawing.SystemColors.Control
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.reserveToolStripButton, Me.historyToolStripButton})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(887, 25)
        Me.ToolStrip1.TabIndex = 0
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'reserveToolStripButton
        '
        Me.reserveToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.reserveToolStripButton.Image = CType(resources.GetObject("reserveToolStripButton.Image"), System.Drawing.Image)
        Me.reserveToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.reserveToolStripButton.Name = "reserveToolStripButton"
        Me.reserveToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.reserveToolStripButton.Text = "Reserve Cab"
        '
        'historyToolStripButton
        '
        Me.historyToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.historyToolStripButton.Image = CType(resources.GetObject("historyToolStripButton.Image"), System.Drawing.Image)
        Me.historyToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.historyToolStripButton.Name = "historyToolStripButton"
        Me.historyToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.historyToolStripButton.Text = "History"
        '
        'NameLabel
        '
        Me.NameLabel.AutoSize = True
        Me.NameLabel.BackColor = System.Drawing.Color.RoyalBlue
        Me.NameLabel.Enabled = False
        Me.NameLabel.Location = New System.Drawing.Point(138, 101)
        Me.NameLabel.Name = "NameLabel"
        Me.NameLabel.Size = New System.Drawing.Size(53, 17)
        Me.NameLabel.TabIndex = 3
        Me.NameLabel.Text = "Name :"
        '
        'totalLabel
        '
        Me.totalLabel.AutoSize = True
        Me.totalLabel.BackColor = System.Drawing.Color.RoyalBlue
        Me.totalLabel.Location = New System.Drawing.Point(138, 225)
        Me.totalLabel.Name = "totalLabel"
        Me.totalLabel.Size = New System.Drawing.Size(130, 17)
        Me.totalLabel.TabIndex = 4
        Me.totalLabel.Text = "Total reservations :"
        '
        'accLabel
        '
        Me.accLabel.AutoSize = True
        Me.accLabel.BackColor = System.Drawing.Color.White
        Me.accLabel.Location = New System.Drawing.Point(138, 341)
        Me.accLabel.Name = "accLabel"
        Me.accLabel.Size = New System.Drawing.Size(97, 17)
        Me.accLabel.TabIndex = 5
        Me.accLabel.Text = "A/C. Balance :"
        '
        'reserveForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(887, 550)
        Me.Controls.Add(Me.accLabel)
        Me.Controls.Add(Me.totalLabel)
        Me.Controls.Add(Me.NameLabel)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Name = "reserveForm"
        Me.Text = "reserveForm"
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents reserveToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents historyToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents NameLabel As System.Windows.Forms.Label
    Friend WithEvents totalLabel As System.Windows.Forms.Label
    Friend WithEvents accLabel As System.Windows.Forms.Label
End Class
