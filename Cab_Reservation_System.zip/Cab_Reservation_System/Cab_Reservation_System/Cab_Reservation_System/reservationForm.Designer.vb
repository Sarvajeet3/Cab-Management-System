﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class reservationForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(reservationForm))
        Me.cabIdTextBox = New System.Windows.Forms.TextBox()
        Me.cabIdLabel = New System.Windows.Forms.Label()
        Me.reservationButton = New System.Windows.Forms.Button()
        Me.reservationDataGridView = New System.Windows.Forms.DataGridView()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.ToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.ddTextBox = New System.Windows.Forms.TextBox()
        Me.ddLabel = New System.Windows.Forms.Label()
        Me.mmTextBox = New System.Windows.Forms.TextBox()
        Me.mmLabel = New System.Windows.Forms.Label()
        Me.yyyyTextBox = New System.Windows.Forms.TextBox()
        Me.yyyyLabel = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.pickLabel = New System.Windows.Forms.Label()
        Me.pickTextBox = New System.Windows.Forms.TextBox()
        CType(Me.reservationDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'cabIdTextBox
        '
        Me.cabIdTextBox.Location = New System.Drawing.Point(470, 358)
        Me.cabIdTextBox.Name = "cabIdTextBox"
        Me.cabIdTextBox.Size = New System.Drawing.Size(182, 22)
        Me.cabIdTextBox.TabIndex = 0
        '
        'cabIdLabel
        '
        Me.cabIdLabel.AutoSize = True
        Me.cabIdLabel.BackColor = System.Drawing.Color.White
        Me.cabIdLabel.Location = New System.Drawing.Point(237, 361)
        Me.cabIdLabel.Name = "cabIdLabel"
        Me.cabIdLabel.Size = New System.Drawing.Size(96, 17)
        Me.cabIdLabel.TabIndex = 1
        Me.cabIdLabel.Text = "Enter Cab ID :"
        '
        'reservationButton
        '
        Me.reservationButton.Location = New System.Drawing.Point(593, 501)
        Me.reservationButton.Name = "reservationButton"
        Me.reservationButton.Size = New System.Drawing.Size(86, 37)
        Me.reservationButton.TabIndex = 2
        Me.reservationButton.Text = "Reserve"
        Me.reservationButton.UseVisualStyleBackColor = True
        '
        'reservationDataGridView
        '
        Me.reservationDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.reservationDataGridView.Location = New System.Drawing.Point(112, 53)
        Me.reservationDataGridView.Name = "reservationDataGridView"
        Me.reservationDataGridView.RowTemplate.Height = 24
        Me.reservationDataGridView.Size = New System.Drawing.Size(612, 271)
        Me.reservationDataGridView.TabIndex = 3
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripButton1})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(887, 25)
        Me.ToolStrip1.TabIndex = 4
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'ToolStripButton1
        '
        Me.ToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton1.Image = CType(resources.GetObject("ToolStripButton1.Image"), System.Drawing.Image)
        Me.ToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton1.Name = "ToolStripButton1"
        Me.ToolStripButton1.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton1.Text = "ToolStripButton1"
        '
        'ddTextBox
        '
        Me.ddTextBox.Location = New System.Drawing.Point(470, 437)
        Me.ddTextBox.Name = "ddTextBox"
        Me.ddTextBox.Size = New System.Drawing.Size(45, 22)
        Me.ddTextBox.TabIndex = 5
        '
        'ddLabel
        '
        Me.ddLabel.AutoSize = True
        Me.ddLabel.BackColor = System.Drawing.Color.White
        Me.ddLabel.Location = New System.Drawing.Point(479, 462)
        Me.ddLabel.Name = "ddLabel"
        Me.ddLabel.Size = New System.Drawing.Size(28, 17)
        Me.ddLabel.TabIndex = 6
        Me.ddLabel.Text = "DD"
        '
        'mmTextBox
        '
        Me.mmTextBox.Location = New System.Drawing.Point(531, 437)
        Me.mmTextBox.Name = "mmTextBox"
        Me.mmTextBox.Size = New System.Drawing.Size(45, 22)
        Me.mmTextBox.TabIndex = 7
        '
        'mmLabel
        '
        Me.mmLabel.AutoSize = True
        Me.mmLabel.BackColor = System.Drawing.Color.White
        Me.mmLabel.Location = New System.Drawing.Point(537, 462)
        Me.mmLabel.Name = "mmLabel"
        Me.mmLabel.Size = New System.Drawing.Size(30, 17)
        Me.mmLabel.TabIndex = 8
        Me.mmLabel.Text = "MM"
        '
        'yyyyTextBox
        '
        Me.yyyyTextBox.Location = New System.Drawing.Point(593, 437)
        Me.yyyyTextBox.Name = "yyyyTextBox"
        Me.yyyyTextBox.Size = New System.Drawing.Size(100, 22)
        Me.yyyyTextBox.TabIndex = 9
        '
        'yyyyLabel
        '
        Me.yyyyLabel.AutoSize = True
        Me.yyyyLabel.BackColor = System.Drawing.Color.White
        Me.yyyyLabel.Location = New System.Drawing.Point(620, 462)
        Me.yyyyLabel.Name = "yyyyLabel"
        Me.yyyyLabel.Size = New System.Drawing.Size(44, 17)
        Me.yyyyLabel.TabIndex = 10
        Me.yyyyLabel.Text = "YYYY"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(237, 440)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(137, 17)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "Date of reservation :"
        '
        'pickLabel
        '
        Me.pickLabel.AutoSize = True
        Me.pickLabel.BackColor = System.Drawing.Color.White
        Me.pickLabel.Location = New System.Drawing.Point(237, 403)
        Me.pickLabel.Name = "pickLabel"
        Me.pickLabel.Size = New System.Drawing.Size(96, 17)
        Me.pickLabel.TabIndex = 12
        Me.pickLabel.Text = "PickUp Point :"
        '
        'pickTextBox
        '
        Me.pickTextBox.Location = New System.Drawing.Point(470, 400)
        Me.pickTextBox.Name = "pickTextBox"
        Me.pickTextBox.Size = New System.Drawing.Size(182, 22)
        Me.pickTextBox.TabIndex = 13
        '
        'reservationForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(887, 550)
        Me.Controls.Add(Me.pickTextBox)
        Me.Controls.Add(Me.pickLabel)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.yyyyLabel)
        Me.Controls.Add(Me.yyyyTextBox)
        Me.Controls.Add(Me.mmLabel)
        Me.Controls.Add(Me.mmTextBox)
        Me.Controls.Add(Me.ddLabel)
        Me.Controls.Add(Me.ddTextBox)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.reservationDataGridView)
        Me.Controls.Add(Me.reservationButton)
        Me.Controls.Add(Me.cabIdLabel)
        Me.Controls.Add(Me.cabIdTextBox)
        Me.Name = "reservationForm"
        Me.Text = "reservationForm"
        CType(Me.reservationDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cabIdTextBox As System.Windows.Forms.TextBox
    Friend WithEvents cabIdLabel As System.Windows.Forms.Label
    Friend WithEvents reservationButton As System.Windows.Forms.Button
    Friend WithEvents reservationDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents ToolStripButton1 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ddTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ddLabel As System.Windows.Forms.Label
    Friend WithEvents mmTextBox As System.Windows.Forms.TextBox
    Friend WithEvents mmLabel As System.Windows.Forms.Label
    Friend WithEvents yyyyTextBox As System.Windows.Forms.TextBox
    Friend WithEvents yyyyLabel As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents pickLabel As System.Windows.Forms.Label
    Friend WithEvents pickTextBox As System.Windows.Forms.TextBox
End Class
