﻿Imports System.Data
Imports System.Data.OleDb

Public Class loginForm

    Dim counter As Integer
    Dim conn As OleDb.OleDbConnection = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\cabDatabase.accdb;Persist Security Info=True")
    Dim cmd As OleDb.OleDbCommand
    Public username, password As String
    Dim sql As String
    Dim dr As IDataReader

    Private Sub loginButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles loginButton.Click
        Try
            username = userNameTextBox.Text
            password = passwordTextBox.Text
            conn.Open()
            sql = "select * from user_table where user_name ='" & username & "' and user_pass='" & password & "'"
            cmd = New OleDbCommand(sql, conn)

            dr = cmd.ExecuteReader()


            If (dr.Read = True) Then
                username = username
                password = password
                conn.Close()
                reserveForm.Show()
                Me.Hide()

            Else

                MessageBox.Show("Username Or Password Incorrect.")
                userNameTextBox.Clear()
                passwordTextBox.Clear()
                userNameTextBox.Focus()
                conn.Close()

            End If
            conn.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub signUpButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles signUpButton.Click
        sign_upForm.Show()
        Me.Hide()
    End Sub

    Private Sub loginForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class
