﻿Imports System.Data
Imports System.Data.OleDb
Public Class reservationForm

    Dim counter, pay As Integer
    Dim conn As OleDb.OleDbConnection = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\cabDatabase.accdb;Persist Security Info=True")
    Dim cmd As OleDb.OleDbCommand
    Dim date_r As String
    Dim sql, paym As String
    Dim dr As IDataReader
    Dim data As OleDbDataReader

    Private Sub reservationButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles reservationButton.Click

        Try
            conn.Open()
            date_r = ddTextBox.Text + "-" + mmTextBox.Text + "-" + yyyyTextBox.Text

            sql = "select reservation_Payment from cab_table where cab_ID=" & cabIdTextBox.Text & ""
            cmd = New OleDbCommand(sql, conn)
            data = cmd.ExecuteReader()
            If data.Read Then
                pay = data("reservation_Payment")
                paym = pay.ToString()


            End If


            sql = "INSERT INTO history_table(  cust_id,payment, pickup_point , Reserved_date, cab_id )VALUES('" & reserveForm.user_id & "','" & paym & "','" & pickTextBox.Text & "','" & date_r & "','" & cabIdTextBox.Text & "');"
            cmd = New OleDbCommand(sql, conn)
            Dim icount As Integer = cmd.ExecuteNonQuery
            MessageBox.Show(" Registered Successfully..", "Success", MessageBoxButtons.OK)
            counter = reserveForm.total_res + 1
            sql = "UPDATE user_table SET acc_balance= acc_balance - '" & paym & "' , total_reservations= '" & counter & "' WHERE user_ID =" & reserveForm.user_id & ""
            cmd = New OleDbCommand(sql, conn)
            cmd.ExecuteNonQuery()
            
            conn.Close()
        Catch ex As Exception
            conn.Close()
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Private Sub reservationForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim ad As OleDbDataAdapter = New OleDbDataAdapter("select * from cab_table", conn)
        Dim ds As DataSet = New DataSet()
        Try

            ad.Fill(ds)
            reservationDataGridView.DataSource = ds.Tables(0)

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub
    
    Private Sub ToolStripButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton1.Click
        Me.Hide()
        reserveForm.Focus()
    End Sub

    Private Sub ToolStrip1_ItemClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles ToolStrip1.ItemClicked

    End Sub
End Class