﻿Imports System.Data
Imports System.Data.OleDb

Public Class reserveForm

    Public user_name As String
    Public acc_bal, total_res, user_id As Integer
    Dim counter As Integer
    Dim conn As OleDb.OleDbConnection = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\cabDatabase.accdb;Persist Security Info=True")
    Dim cmd As OleDb.OleDbCommand
    Dim sql, y, m, d, thisDate, acc, total As String
    Dim dr As IDataReader
    Dim data As OleDbDataReader
    Dim thisYear, thisMonth, thisDay As Integer

    Private Sub reserveForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        

        Try
            thisYear = Today.Year
            thisMonth = Today.Month
            thisDay = Today.Day
            y = thisYear.ToString()
            m = thisMonth.ToString()
            d = thisDay.ToString()

            thisDate = d + "-" + m + "-" + y

            conn.Open()

            sql = "select user_ID, user_name, acc_balance, total_reservations from user_table where user_name ='" & loginForm.username & "' and user_pass='" & loginForm.password & "'"
            cmd = New OleDbCommand(sql, conn)
            data = cmd.ExecuteReader()

            If data.Read Then
                user_id = data("user_ID")
                user_name = data("user_name")
                acc_bal = data("acc_balance")
                total_res = data("total_reservations")
            End If


            acc = acc_bal.ToString()
            total = total_res.ToString()

            NameLabel.Text = NameLabel.Text + "                                 " + user_name
            totalLabel.Text = totalLabel.Text + "   " + total
            accLabel.Text = accLabel.Text + "        " + acc


        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub historyToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles historyToolStripButton.Click
        historyForm.Show()
        historyForm.Focus()
    End Sub

    Private Sub reserveToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles reserveToolStripButton.Click
        reservationForm.Show()
        reservationForm.Focus()
    End Sub

    Private Sub ToolStrip1_ItemClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles ToolStrip1.ItemClicked

    End Sub
End Class