﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class loginForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(loginForm))
        Me.userNameTextBox = New System.Windows.Forms.TextBox()
        Me.passwordTextBox = New System.Windows.Forms.TextBox()
        Me.userNameLabel = New System.Windows.Forms.Label()
        Me.passwordLabel = New System.Windows.Forms.Label()
        Me.loginButton = New System.Windows.Forms.Button()
        Me.signUpButton = New System.Windows.Forms.Button()
        Me.logInLabel = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'userNameTextBox
        '
        Me.userNameTextBox.Location = New System.Drawing.Point(339, 233)
        Me.userNameTextBox.Name = "userNameTextBox"
        Me.userNameTextBox.Size = New System.Drawing.Size(279, 22)
        Me.userNameTextBox.TabIndex = 0
        '
        'passwordTextBox
        '
        Me.passwordTextBox.Location = New System.Drawing.Point(339, 306)
        Me.passwordTextBox.Name = "passwordTextBox"
        Me.passwordTextBox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.passwordTextBox.Size = New System.Drawing.Size(279, 22)
        Me.passwordTextBox.TabIndex = 1
        '
        'userNameLabel
        '
        Me.userNameLabel.AutoSize = True
        Me.userNameLabel.BackColor = System.Drawing.Color.RoyalBlue
        Me.userNameLabel.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.userNameLabel.Location = New System.Drawing.Point(156, 238)
        Me.userNameLabel.Name = "userNameLabel"
        Me.userNameLabel.Size = New System.Drawing.Size(73, 17)
        Me.userNameLabel.TabIndex = 2
        Me.userNameLabel.Text = "Username"
        '
        'passwordLabel
        '
        Me.passwordLabel.AutoSize = True
        Me.passwordLabel.BackColor = System.Drawing.Color.RoyalBlue
        Me.passwordLabel.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.passwordLabel.Location = New System.Drawing.Point(156, 309)
        Me.passwordLabel.Name = "passwordLabel"
        Me.passwordLabel.Size = New System.Drawing.Size(69, 17)
        Me.passwordLabel.TabIndex = 3
        Me.passwordLabel.Text = "Password"
        '
        'loginButton
        '
        Me.loginButton.BackColor = System.Drawing.SystemColors.Control
        Me.loginButton.Location = New System.Drawing.Point(286, 427)
        Me.loginButton.Margin = New System.Windows.Forms.Padding(0)
        Me.loginButton.Name = "loginButton"
        Me.loginButton.Size = New System.Drawing.Size(84, 33)
        Me.loginButton.TabIndex = 4
        Me.loginButton.Text = "Log-In"
        Me.loginButton.UseVisualStyleBackColor = False
        '
        'signUpButton
        '
        Me.signUpButton.Location = New System.Drawing.Point(454, 427)
        Me.signUpButton.Name = "signUpButton"
        Me.signUpButton.Size = New System.Drawing.Size(77, 32)
        Me.signUpButton.TabIndex = 5
        Me.signUpButton.Text = "Sign-up?"
        Me.signUpButton.UseVisualStyleBackColor = True
        '
        'logInLabel
        '
        Me.logInLabel.AutoSize = True
        Me.logInLabel.BackColor = System.Drawing.Color.RoyalBlue
        Me.logInLabel.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.logInLabel.Image = CType(resources.GetObject("logInLabel.Image"), System.Drawing.Image)
        Me.logInLabel.Location = New System.Drawing.Point(336, 80)
        Me.logInLabel.Name = "logInLabel"
        Me.logInLabel.Size = New System.Drawing.Size(48, 17)
        Me.logInLabel.TabIndex = 6
        Me.logInLabel.Text = "Log-In"
        '
        'loginForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(770, 641)
        Me.Controls.Add(Me.logInLabel)
        Me.Controls.Add(Me.signUpButton)
        Me.Controls.Add(Me.loginButton)
        Me.Controls.Add(Me.passwordLabel)
        Me.Controls.Add(Me.userNameLabel)
        Me.Controls.Add(Me.passwordTextBox)
        Me.Controls.Add(Me.userNameTextBox)
        Me.DoubleBuffered = True
        Me.Name = "loginForm"
        Me.Text = "Log-In"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents userNameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents passwordTextBox As System.Windows.Forms.TextBox
    Friend WithEvents userNameLabel As System.Windows.Forms.Label
    Friend WithEvents passwordLabel As System.Windows.Forms.Label
    Friend WithEvents loginButton As System.Windows.Forms.Button
    Friend WithEvents signUpButton As System.Windows.Forms.Button
    Friend WithEvents logInLabel As System.Windows.Forms.Label

End Class
